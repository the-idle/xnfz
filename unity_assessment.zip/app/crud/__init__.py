# 让 crud 成为包

from . import crud_user
from . import crud_platform
from . import crud_question_bank
from . import crud_question
from . import crud_assessment
from . import crud_assessment_result
from . import crud_answer_log



